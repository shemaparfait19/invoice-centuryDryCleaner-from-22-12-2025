# Century Dry Cleaner - Portable Version 
 
This is a portable version of the Century Dry Cleaner application. 
 
## How to Use: 
1. Double-click RUN_ME_FIRST.txt and follow the instructions 
2. Then double-click INSTALL_AND_RUN.bat to start the application 
